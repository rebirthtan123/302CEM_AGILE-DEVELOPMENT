

 
<?php $__env->startSection('content'); ?>

<style>
  * {
    box-sizing: border-box;
  }
  
  .row {
    margin-left:5px;
    margin-right:5px;
  }
    
  .column {
    float: left;
    width: 50%;
    padding: 5px;
  }
  
  /* Clearfix (clear floats) */
  .row::after {
    content: "";
    clear: both;
    display: table;
  }
  
  table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
  }
  

  </style>

<div class="row">
  <div class="column">
    <div class="col-lg-13">
      <div class="card mb-3">
        <div class="card-header">
          <i class="fas fa-utensils"></i>
          Menu</div>
          <div class="card-body">
            <table class="table table-bordered text-center" width="100%" cellspacing="0">
            <tr>
              <th>No</th>
              <th>Category Name</th>
              <th>Item Name</th>
              <th>Price</th>
             
           </tr>
           <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

           <tr>
            <td> <?php echo e($menu->id); ?></td>
             <td><?php echo e($menu->categoryName); ?></td>
               <td><?php echo e($menu->itemName); ?></td>
               <td><?php echo e($menu->price); ?></td>
              
           </tr>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>
          </div>
      </div>
    </div>
  </div>

  <form action="<?php echo e(route('staff.addOrder.store',['id'=>$table->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>

    

    <div class="card">
        <div class="card-header">
            Ordering
        </div>

        <div class="card-body">
            <table class="table" id="menus_table">
                <thead>
                  <tr>
                    <div class="form-group <?php echo e($errors->has('table_id') ? 'has-error' : ''); ?>">
                      <label for="table_id">Table Id</label>
                      <input type="text" id="table_id" name="table_id" class="form-control" value="<?php echo e($table->id); ?><?php echo e(old('table_id', isset($order) ? $order->table_id : '')); ?>" required>
                      <?php if($errors->has('table_id')): ?>
                          <em class="invalid-feedback">
                              <?php echo e($errors->first('table_id')); ?>

                          </em>
                      <?php endif; ?>
                  </div>
                  </tr>
                    <tr>
                        <th>Food</th>
                        <th>Quantity</th>
                    </tr>
                </thead>
                <tbody>
                    <tr id="menu0">
                        <td>
                            <select name="menus[]" class="form-control">
                                <option value="">-- choose menu --</option>
                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($menu->id); ?>">
                                        <?php echo e($menu->itemName); ?> ($<?php echo e(number_format($menu->price, 2)); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                        <td>
                            <input type="number" name="quantities[]" class="form-control" value="1" />
                        </td>
                    </tr>
                    <tr id="menu1"></tr>
                </tbody>
            </table>

            <div class="row">
                <div class="col-md-12">
                    <button id="add_row" class="btn btn-default pull-left">+ Add Row</button>
                    <button id='delete_row' class="pull-right btn btn-danger">- Delete Row</button>
                </div>
            </div>
        </div>
    </div>
    <div>
        <input class="btn btn-primary" type="submit" value="save">
    </div>
</form>
</div>

<script>
  $(document).ready(function(){
    let row_number = <?php echo e(count(old('menus', ['']))); ?>;
    $("#add_row").click(function(e){
      e.preventDefault();
      let new_row_number = row_number - 1;
      $('#menu' + row_number).html($('#menu' + new_row_number).html()).find('td:first-child');
      $('#menus_table').append('<tr id="menu' + (row_number + 1) + '"></tr>');
      row_number++;
    });

    $("#delete_row").click(function(e){
      e.preventDefault();
      if(row_number > 1){
        $("#menu" + (row_number - 1)).html('');
        row_number--;
      }
    });
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/staff/addOrder.blade.php ENDPATH**/ ?>