
 
<?php $__env->startSection('content'); ?>

<div id="overlay" onclick="off()">
    <div id="image"><img src="/images/MapView.PNG" alt=""></div>
  </div>
  
  <div style="padding:20px">
    <h2>Table Map View</h2>
    <button onclick="on()">Map View Button</button>
  </div>

<div class="card-body">
<table class="table table-bordered text-center">
    <tr>
        <th>No</th>
        <th>Name</th>
        <th>Image</th>
        <th>Status</th>
        <th width="250px">Action</th>
    </tr>
    <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($table->id); ?></td>
        <td><?php echo e($table->name); ?></td>
        <td><img src="data:image/png;base64,<?php echo e(chunk_split(base64_encode($table->src))); ?>" height="100" width="100" alt="table"></td>
        <td><?php echo e($table->status); ?></td>
        <td>            
            <a class="btn btn-info" href="<?php echo e(route('staff.addOrder',['id'=>$table->id])); ?>">Select</a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

</div>

<script>
    function on() {
      document.getElementById("overlay").style.display = "block";
    }
    
    function off() {
      document.getElementById("overlay").style.display = "none";
    }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2021 software\testing\restaurant\resources\views/staff/table.blade.php ENDPATH**/ ?>