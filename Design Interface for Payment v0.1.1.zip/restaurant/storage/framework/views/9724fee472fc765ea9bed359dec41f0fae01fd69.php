
<?php $__env->startSection('content'); ?>

<br><br>

    <div class="col-lg-6">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-chart-bar"></i>
           Button</div>
          <div class="card-body">
              
                  <table id="tblOrderList" class="table table-bordered text-center" width="50%" cellspacing="0">
                      <tr>
                          <th> <button type="button" class="btn btn-secondary"><a href="<?php echo e(asset('staff/table')); ?>" style="text-decoration: none">Add Order</button></th>
                          <th><button type="button" class="btn btn-secondary"><a href="#" style="text-decoration: none">Kitchen</button></th>
                          <th><button type="button" class="btn btn-secondary"><a href="<?php echo e(route('auth.login')); ?>" style="text-decoration: none">Logout</button></th>
     
                      </tr>
                  </table>
                  
              
          </div>
        </div>
      </div>

 
      <div class="col-lg-6">
        <div class="card mb-3">
          <div class="card-header">
            <i class="fas fa-chart-bar"></i>
           Current Order List</div>
          <div class="card-body">
              
                  <table id="tblOrderList" class="table table-bordered text-center" width="100%" cellspacing="0">
                      <tr>
                          <th>id</th>
                          <th>table</th>
                          <th>Food (Quantity & Price)</th>
                          <th>Time</th>
                          <th>status</th>
                          <th>Payment</th>
                          <th>Action</th>

                      </tr>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr data-entry-id="<?php echo e($order->id); ?>">
                          <td>
                              <?php echo e($order->id ?? ''); ?>

                          </td>
                          <td>
                              <?php echo e($order->table_id ?? ''); ?>

                          </td>
                          
                          <td>
                              <ul>
                              <?php $__currentLoopData = $order->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($item->itemName); ?> (<?php echo e($item->pivot->quantity); ?> x $<?php echo e($item->price); ?>)</li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                          </td>
                          <td>
                            <?php echo e($order->created_at ?? ''); ?>

                          </td>
                          <td>
                            <?php echo e($order->status ?? ''); ?>

                          </td>
                          
                          <td>
                           
                              
                                <button><a class="btn btn-danger" onclick="return confirm('The total amount is RM  <?php $__currentLoopData = $order->menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo e($item->pivot->quantity); ?> * <?php echo e($item->price); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>.')" >
                                cash</a></button>

                                <br><br>
                                
                                <button><a class="btn btn-danger" onclick="return confirm('The total amount is RM <?php echo e($item->pivot->quantity * $item->price); ?>.')" >
                                Card</a></button>
                             
                          </td>
                          <td>
                            Cancel
                          </td>

                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                  
              
          </div>
        </div>
      </div>

    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\restaurant\resources\views/staff/mainmenu.blade.php ENDPATH**/ ?>