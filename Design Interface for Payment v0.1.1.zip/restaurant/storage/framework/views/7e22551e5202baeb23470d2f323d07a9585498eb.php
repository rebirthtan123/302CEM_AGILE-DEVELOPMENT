

 
<?php $__env->startSection('content'); ?>
<?php echo e($table['name']); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2021 software\testing\restaurant\resources\views/staff/detail.blade.php ENDPATH**/ ?>