
 
<?php $__env->startSection('content'); ?>
<br><br>
<div class="row" >
    <div class="col-lg-6">
      <div class="card mb-3">
        <div class="card-header">
          <i class="fas fa-utensils"></i>
          Take Order</div>
        <div class="card-body">
          <table class="table table-bordered text-center" width="100%" cellspacing="0">
            <tr>
              <th>No</th>
              <th>Category Name</th>
              <th>Item Name</th>
              <th>Price</th>
              <th>Quantity</th>
              <th width="250px">Action</th>
          </tr>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="#" method="post">
            <tr>
             <td> <?php echo e($menu->id); ?></td>
              <td><?php echo e($menu->categoryName); ?></td>
                <td><?php echo e($menu->itemName); ?></td>
                <td><?php echo e($menu->price); ?></td>
                <td>
                      <input type="text">
                  </form>
                </td>
                <td>
                    <button>Add</button>
                </td>
            </tr>
          </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </table>
          <table id="tblItem" class="table table-bordered text-center" width="100%" cellspacing="0"></table>

        <div id="qtypanel" hidden="">
                    Quantity : <input id="qty" required="required" type="number" min="1" max="50" name="qty" value="1" />
                    <button class="btn btn-info" onclick = "insertItem()">Done</button>
                    <br><br>
        </div>

        </div>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\2021 software\testingg\new\restaurant\resources\views/staff/addOrder.blade.php ENDPATH**/ ?>